# Demo Leveraging Route 53 and ACM for Secure DNS

---

## Important Information

For sake of simplicity of executing the code in the demos during this module, we have decided to keep the manifest files
and python code within one single directory.

You can find the `9-tls-ingress-config.yaml` manifest file in the Module 3 Directory located here:

[Module 3 - Manifest Files](../3_managing_and_deploying_your_eks_cluster/manifest_files/)

Perform the operations from that module directory for this to work, if you are following along directly.

> This specific file is generated during the demos, so it does not exist beforehand.