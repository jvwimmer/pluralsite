# Demo Creating a Kubernetes Ingress (ALB)

---

## Important Information

For sake of simplicity of executing the code in the demos during this module, we have decided to keep the manifest files
and python code within one single directoy.

You can find them in the Module 3 Directory located here:

[Module 3 - 7-ingressClass-config Manifest File](../3_managing_and_deploying_your_eks_cluster/manifest_files/7-ingressClass-config)

[Module 3 - 8-ingress-config Manifest File](../3_managing_and_deploying_your_eks_cluster/manifest_files/8-ingress-config.yaml)

Perform the operations from that module directory for this to work, if you are following along directly.