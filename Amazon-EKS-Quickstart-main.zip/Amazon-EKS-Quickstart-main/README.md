# Amazon-EKS-Quickstart

Welcome to the Amazon EKS Quickstart course at Pluralsight!
Within this course you will work through different demo examples of leveraging Amazon EKS to run sample applications.

