# Demo: Creating an Amazon EKS Cluster with ekstcl

The following script/command will create a brand-new EKS cluster and VPC network with the default settings.

```shell
eksctl create cluster
```
